import json

def lambda_handler(event, context):
    for record in event['Records']:
        # Extract the bucket name and key from the event record
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Log the bucket and key
        print("S3 Event - Bucket: {}, Key: {}".format(bucket, key))

    # Return a response if necessary
    return {
        'statusCode': 200,
        'body': 'S3 event processed successfully'
    }
