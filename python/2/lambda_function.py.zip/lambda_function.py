import boto3
import json

def lambda_handler(event, context):
    # Log the incoming SQS event
    print("Received SQS event: {}".format(json.dumps(event)))

    # Specify the S3 bucket and key for storing the event
    s3_bucket = 'corelight-demo-1'
    s3_key = 'arn:aws:kms:us-east-1:*:key/*'

    # Create an S3 client
    s3_client = boto3.client('s3')

    # Put the event into the S3 bucket
    response = s3_client.put_object(
        Body=json.dumps(event),
        Bucket=s3_bucket,
        Key=s3_key
    )

    # Return a response if necessary
    return {
        'statusCode': 200,
        'body': 'Event stored in S3 successfully'
    }
