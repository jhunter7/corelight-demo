import boto3

def lambda_handler(event, context):
    # Specify the name of the log group
    log_group_name = '/aws/lambda/corelight-demo-lambda-1'

    # Create a CloudWatch Logs client
    logs_client = boto3.client('logs')

    # Get the log streams for the specified log group
    response = logs_client.describe_log_streams(
        logGroupName=log_group_name,
        orderBy='LastEventTime',
        descending=True
    )

    # Extract the log streams from the response
    log_streams = response['logStreams']

    # Output the log stream names
    for log_stream in log_streams:
        print(log_stream['logStreamName'])

    # Return a response if necessary
    return {
        'statusCode': 200,
        'body': log_streams[0]
    }
